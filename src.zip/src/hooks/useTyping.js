import { useEffect, useState } from "react";
import { calculateStats } from "../utils/calculateStats";

export default function useTyping(text) {

  const [typed, setTyped] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [started, setStarted] = useState(false);
  const [startTime, setStartTime] = useState(0);

  useEffect(() => {

    function handleKey(e) {

      if (e.key.length !== 1 && e.key !== "Backspace")
        return;

      if (!started) {
        setStarted(true);
        setStartTime(Date.now());
      }

      if (e.key === "Backspace") {

        setTyped(prev => prev.slice(0, -1));

        setCurrentIndex(prev =>
          Math.max(prev - 1, 0)
        );

        return;
      }

      setTyped(prev => [...prev, e.key]);

      setCurrentIndex(prev => prev + 1);

    }

    window.addEventListener("keydown", handleKey);

    return () =>
      window.removeEventListener("keydown", handleKey);

  }, [started]);

  const stats = calculateStats(
    text,
    typed,
    startTime
  );

  return {
    typed,
    currentIndex,
    stats,
  };
}