import { Routes, Route } from "react-router-dom";

import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";

import Home from "./pages/Home/Home";
import Test from "./pages/Test/Test";

function App() {
  return (
    <div className="min-h-screen bg-[#09090b] text-white">

      <Navbar />

      <Routes>

        <Route path="/" element={<Home />} />

        <Route path="/test" element={<Test />} />

      </Routes>

      <Footer />

    </div>
  );
}

export default App;