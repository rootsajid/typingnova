function Footer() {
  return (
    <footer className="mt-24 border-t border-zinc-800">

      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-6 py-10 md:flex-row">

        <h2 className="bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-3xl font-black text-transparent">
          TypeNova
        </h2>

        <p className="text-zinc-500">
          © 2026 TypeNova • Built with React 19
        </p>

      </div>

    </footer>
  );
}

export default Footer;