import paragraphs from "../../data/paragraphs";
import useTyping from "../../hooks/useTyping";
import TypingStats from "./TypingStats";

function TypingArea() {

  const text = paragraphs[0];

  const {
    typed,
    currentIndex,
    stats,
  } = useTyping(text);

  return (
    <>
      <TypingStats stats={stats} />

      <div className="rounded-3xl border border-zinc-800 bg-zinc-900 p-8 text-3xl leading-loose">

        {text.split("").map((char,index)=>{

          let cls="text-zinc-600";

          if(index<typed.length){

            cls=
              typed[index]===char
              ?"text-green-400"
              :"text-red-500";

          }

          if(index===currentIndex){

            cls+=" border-l-2 border-purple-500";

          }

          return(
            <span
              key={index}
              className={cls}
            >
              {char}
            </span>
          );

        })}

      </div>

    </>
  );

}

export default TypingArea;