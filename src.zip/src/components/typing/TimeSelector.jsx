const times = [15, 30, 60, 120];

function TimeSelector({ selected, setSelected }) {
  return (
    <div className="flex flex-wrap justify-center gap-3">
      {times.map((time) => (
        <button
          key={time}
          onClick={() => setSelected(time)}
          className={`rounded-xl px-5 py-2 transition ${
            selected === time
              ? "bg-purple-600 text-white"
              : "bg-zinc-900 text-zinc-400 hover:bg-zinc-800"
          }`}
        >
          {time}s
        </button>
      ))}
    </div>
  );
}

export default TimeSelector;