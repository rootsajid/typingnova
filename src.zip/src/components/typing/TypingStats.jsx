function TypingStats({ stats }) {

  return (

    <div className="mb-12 flex justify-center gap-10 text-xl">

      <div>
        ⚡ {stats.wpm} WPM
      </div>

      <div>
        🎯 {stats.accuracy}%
      </div>

      <div>
        ❌ {stats.wrong}
      </div>

    </div>

  );

}

export default TypingStats;