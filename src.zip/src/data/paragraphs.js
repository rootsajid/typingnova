const paragraphs = [
  "The quick brown fox jumps over the lazy dog.",
  "Practice every day to improve your typing speed and accuracy.",
  "TypeNova is built with React and modern web technologies."
];

export default paragraphs;