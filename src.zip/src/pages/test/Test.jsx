import TypingArea from "../../components/typing/TypingArea";

function Test() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">

      <h1 className="mb-10 text-center text-5xl font-black">
        Typing Test
      </h1>

      <TypingArea />

    </div>
  );
}

export default Test;